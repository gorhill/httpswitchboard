//// Injected into content pages
//
//// rhill 2013-11-09: Weird... This code is executed from HTTP Switchboard
//// context first time extension is launched. Avoid this.
//if ( /^https?:\/\/./.test(window.location.href) ) {
//
///******************************************************************************/
//
//var localStorageHandler = function(mustRemove) {
//    if ( mustRemove ) {
//        window.localStorage.clear();
//        // console.debug('HTTP Switchboard > found and removed non-empty localStorage');
//    }
//};
//
///*----------------------------------------------------------------------------*/
//
//// This is to take care of
//// https://code.google.com/p/chromium/issues/detail?id=232410
//// We look up noscript tags and force the DOM parser to parse
//// them.
//var fixNoscriptTags = function() {
//    var a = document.querySelectorAll('noscript');
//    var i = a.length;
//    var html;
//    while ( i-- ) {
//        html = a[i].innerHTML;
//        html = html.replace(/&lt;/g, '<');
//        html = html.replace(/&gt;/g, '>');
//        a[i].innerHTML = html;
//    }
//};
//
///*----------------------------------------------------------------------------*/
//
//var collectExternalResources = function() {
//    var r = {
//        refCounter: 0,
//        locationURL: window.location.href,
//        scriptSources: {}, // to avoid duplicates
//        pluginSources: {}, // to avoid duplicates
//        localStorage: false,
//        indexedDB: false
//    };
//    var i, elem, elems;
//
//    // https://github.com/gorhill/httpswitchboard/issues/25
//    elems = document.querySelectorAll('script');
//    i = elems ? elems.length : 0;
//    while ( i-- ) {
//        elem = elems[i];
//        if ( elem.innerText.trim() !== '' ) {
//            r.scriptSources['{inline_script}'] = true;
//        }
//        if ( elem.src && elem.src.trim() !== '' ) {
//            r.scriptSources[elem.src.trim()] = true;
//        }
//    }
//
//    // Looks for inline javascript also in at least one a[href] element.
//    // https://github.com/gorhill/httpswitchboard/issues/131
//    if ( document.querySelector('a[href^="javascript:"]') ) {
//        r.scriptSources['{inline_script}'] = true;
//    }
//
//    // https://github.com/gorhill/httpswitchboard/issues/25
//    elems = document.querySelectorAll('object');
//    i = elems.length;
//    while ( i-- ) {
//        elem = elems[i];
//        if ( elem.data && elem.data.trim() !== '' ) {
//            r.pluginSources[elem.data.trim()] = true;
//        }
//    }
//
//    // https://github.com/gorhill/httpswitchboard/issues/25
//    elems = document.querySelectorAll('embed');
//    i = elems.length;
//    while ( i-- ) {
//        elem = elems[i];
//        if ( elem.src && elem.src.trim() !== '' ) {
//            r.pluginSources[elem.src.trim()] = true;
//        }
//    }
//
//    // Check for non-empty localStorage
//    if ( window.localStorage && window.localStorage.length ) {
//        r.localStorage = true;
//        chrome.runtime.sendMessage({
//            what: 'contentScriptHasLocalStorage',
//            url: r.locationURL
//        }, localStorageHandler);
//    }
//
//    // TODO: indexedDB
//    if ( window.indexedDB && !!window.indexedDB.webkitGetDatabaseNames ) {
//        // var db = window.indexedDB.webkitGetDatabaseNames().onsuccess = function(sender) {
//        //    console.debug('webkitGetDatabaseNames(): result=%o', sender.target.result);
//        // };
//    }
//
//    // TODO: Web SQL
//    if ( window.openDatabase ) {
//        // Sad:
//        // "There is no way to enumerate or delete the databases available for an origin from this API."
//        // Ref.: http://www.w3.org/TR/webdatabase/#databases
//    }
//
//    // Important!!
//    chrome.runtime.sendMessage({
//        what: 'contentScriptSummary',
//        details: r
//    });
//};
//
///*----------------------------------------------------------------------------*/
//
//var loadHandler = function() {
//    fixNoscriptTags();
//    collectExternalResources();
//};
//
///*----------------------------------------------------------------------------*/
//
//// rhill 2014-01-26: If document is already loaded, handle all immediately,
//// otherwise defer to later when document is loaded.
//// https://github.com/gorhill/httpswitchboard/issues/168
//if ( document.readyState === 'interactive' ) {
//    loadHandler();
//} else {
//    window.addEventListener('load', loadHandler);
//}
//
///******************************************************************************/
//
//}


//=============================================================================//
"use strict";

if ( ! /^https?:\/\/./.test(window.location.href) )
   return;

/******************************************************************************/
function localStorageHandler(mustRemove) {
    if ( mustRemove ) {
        window.localStorage.clear();
        // console.debug('HTTP Switchboard > found and removed non-empty localStorage');
    }
}
/******************************************************************************/

var hasNoInlineScript = true,
    fixingNoscript = false,
    doSendMessage = false;

var r = {
    refCounter: 0,
    locationURL: window.location.href,
    scriptSources: {}, // to avoid duplicates
    pluginSources: {}, // to avoid duplicates
    localStorage: false,
    indexedDB: false
};

//-----------------------------------------------------------------------//
var boolScriptBlacklisted = false;

var checkScriptBlacklistedHandler = function(response) {
   boolScriptBlacklisted = response.scriptBlacklisted;
}

chrome.runtime.sendMessage({ what: 'checkScriptBlacklisted',
                             url: window.location.href
                           }, checkScriptBlacklistedHandler );
//-----------------------------------------------------------------------//

// Check for non-empty localStorage
if ( window.localStorage && window.localStorage.length ) {
    r.localStorage = true;
    chrome.runtime.sendMessage({
        what: 'contentScriptHasLocalStorage',
        url: r.locationURL
    }, localStorageHandler);
}

//============================================================================//

var winMessage = function(event)
{
   var subframeData = event.data;

   if(self==top)
   {
      console.log(subframeData.details);

      subframeData.details.locationURL = window.location.href;
      chrome.runtime.sendMessage({
              what: 'contentScriptSummary',
              details: subframeData.details
      });
   }
   else
   {
      parent.postMessage( subframeData, "*");
   }
}

window.addEventListener('message', winMessage, false);

function handleSummary(summaries)
{
   var i = summaries.length,
         j,
         tmpSummary,
         elem;

     while ( i-- )
     {
        tmpSummary = summaries[i];

        j = tmpSummary.added.length;

        while( j-- )
        {
           elem =tmpSummary.added[j];

           switch( elem.nodeName )
           {
              case "A":
                 if( hasNoInlineScript && elem.href.indexOf('javascript:') == 0) {
                    r.scriptSources[((self==top)?'{inline_script}':r.locationURL+"_{inline_script}")] = true;
                    hasNoInlineScript = false;
                    doSendMessage = true;
                 }
                 break;
              
              case "EMBED":
                 if ( elem.src && elem.src.trim() !== '' ) {
                    r.pluginSources[elem.src.trim()] = true;
                    doSendMessage = true;
                 }
                 break;
              
              case "NOSCRIPT":
                 if( boolScriptBlacklisted ) {
                    var noscriptParent = elem.parentElement,
                        fakeNoscript = document.createElement('div');
                    fakeNoscript.innerHTML = "<!--NOSCRIPT-->\n"+elem.textContent;
                    fakeNoscript.setAttribute("class", "fakeNoscript");
                    noscriptParent.removeChild(elem);
                    noscriptParent.appendChild(fakeNoscript);
                 }
                 break;
              
              case "OBJECT":
                 if ( elem.data && elem.data.trim() !== '' ) {
                    r.pluginSources[elem.data.trim()] = true;
                    doSendMessage = true;
                 }
                 break;
              
              case "SCRIPT":
                 if ( hasNoInlineScript && elem.innerText.trim() !== '' ) {
                    r.scriptSources[((self==top)?'{inline_script}':r.locationURL+"_{inline_script}")] = true;
                    hasNoInlineScript = false;
                 }
                 else if ( elem.src && elem.src.trim() !== '' ) {
                    r.scriptSources[elem.src.trim()] = true;
                    doSendMessage = true;
                 }
                 break;
           }
        }
     }

     if ( doSendMessage )
     {
        if ( self==top )
        {
          // Important!!
          chrome.runtime.sendMessage({
              what: 'contentScriptSummary',
              details: r
          });
          doSendMessage = false;
       }
       else
       {
         parent.postMessage({what: "subframe_contentScript", details: r}, "*");
         doSendMessage = false;
       }
     }

}

var observerSummary = new MutationSummary({ callback: handleSummary,
                                            queries: [{ element: "a, embed, noscript, object, script" }] });

// Don't know if this is needed
// Just doing this to be safe?
window.onbeforeunload = function()
{
      if(observerSummary)
         observerSummary.disconnect();
      window.removeEventListener("message", winMessage, false);
}
//============================================================================//


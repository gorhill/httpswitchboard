### This is HTTP Switchboard's manifesto

1. The **user decides** what web content is acceptable or not in their browser.

That is all.

The purpose of _HTTP Switchboard_ is to give the user the means for informed
consent and informed dissent.

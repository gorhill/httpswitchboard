/*******************************************************************************

    httpswitchboard - a Chromium browser extension to black/white list requests.
    Copyright (C) 2013  Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/httpswitchboard
*/

/******************************************************************************/

function gethttpsb() {
    return chrome.extension.getBackgroundPage().HTTPSB;
}

/******************************************************************************/

function renderPermissionToString(permission) {
    return '\t\t' + permissions[i].replace('|',' ') + '\n';
}

/******************************************************************************/

function renderListToString(listName, list) {
    var s = '\t' + listName + '\n';
    var permissions = Object.keys(list);
    var i = permissions.count;
    while ( i-- ) {
        s += renderPermissionToString(permissions[i]);
    }
    return s;
}

/******************************************************************************/

function renderScopeToString(scopeKey, scope) {
    var s = scopeKey + '\n';
    s += renderListToString('white', scope.white);
    s += renderListToString('black', scope.black);
    s += renderListToString('gray', scope.gray);
    return s;
}

/******************************************************************************/

function renderAllScopesToString(scopes) {
    var s = '';
    var scopeKeys = Object.keys(httpsb.temporaryScopes.scopes);
    var i = scopeKeys.length;
    while ( i-- ) {
        s += httpsb.temporaryScopes.scopes[scopeKeys[i]];
    }
    return s;
}

/******************************************************************************/

var friendlyTypeNames = {
    '*': '*',
    'main_frame': 'pages',
    'cookie': 'cookies/local storages',
    'image': 'images',
    'object': 'plugins',
    'script': 'scripts',
    'xmlhttprequest': 'XMLHttpRequests',
    'sub_frame': 'frames',
    'other': 'Other',
};

function renderPermissionToHTML(permissionKey) {
    var parts = permissionKey.split('|');
    return (parts[1] === '*' ? '*' : parts[1]) + ' ' + friendlyTypeNames[parts[0]];
}

/******************************************************************************/

function renderScopeKeyToHTML(scopeKey) {
    if ( scopeKey === '*' ) {
        return 'Global permissions';
    }
    return '<a href="' + scopeKey + '">' + scopeKey + '</a>';
}

/******************************************************************************/

function renderAll() {
    var httpsb = gethttpsb();

    // Iterate scopes
    var scopeKeys = Object.keys(httpsb.temporaryScopes.scopes);
    var iScope = scopeKeys.length;
    var scopeKey;
    var html = [];
    var hostnames, iHostname, hostname;

    var lists = ['gray', 'black', 'white'];
    var iList;

    html.push('<ul>');
    while ( iScope-- ) {
        scopeKey = scopeKeys[iScope];
        html.push('<li>');
        html.push(renderScopeKeyToHTML(scopeKey));
        html.push(' <input class="ro" type="text" readonly="readonly" value="');
        html.push(encodeURIComponent(renderScopeToString(scopeKey, httpsb.temporaryScopes.scopes[scopeKey])));
        html.push('">');
        html.push('<ul>');
        iList = lists.length;
        while ( iList-- ) {
            permissions = Object.keys(httpsb.temporaryScopes.scopes[scopeKey][lists[iList]].list);
            iPermission = permissions.length;
            if ( iPermission === 0 ) {
                continue;
            }
            html.push('<li class=' + lists[iList] + '>');
            html.push(lists[iList] + 'list');
            html.push('<ul>');
            while ( iPermission-- ) {
                html.push('<li>');
                html.push(renderPermissionToHTML(permissions[iPermission]));
            }
            html.push('</ul>');
        }
        html.push('</ul>');
    }
    html.push('</ul>');

    $('#permission-tree').html(html.join(''));
}

/******************************************************************************/

$(function() {
    renderAll();
});

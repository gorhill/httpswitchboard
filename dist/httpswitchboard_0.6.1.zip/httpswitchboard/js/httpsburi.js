/*******************************************************************************

    httpswitchboard - a Chromium browser extension to black/white list requests.
    Copyright (C) 2013  Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/httpswitchboard
*/

/*******************************************************************************

 HTTPSB deals *only* with absolute URI.

 RFC 3986 as reference: http://tools.ietf.org/html/rfc3986#appendix-A

*/

/******************************************************************************/

function HTTPSBURI(s) {
    this.reset().uri(s);
}

/******************************************************************************/

HTTPSBURI.prototype.hostnameRegex = /^([a-z\d]+(-*[a-z\d]+)*)(\.[a-z\d]+(-*[a-z\d])*)*$/;

// Source.: http://stackoverflow.com/questions/5284147/validating-ipv4-addresses-with-regexp/5284410#5284410
HTTPSBURI.prototype.ipv4Regex = /^((25[0-5]|2[0-4]\d|[01]?\d\d?)(\.|$)){4}/;

// Source: http://forums.intermapper.com/viewtopic.php?p=1096#1096
HTTPSBURI.prototype.ipv6Regex = /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/;

/******************************************************************************/

HTTPSBURI.prototype.reset = function() {
    this._scheme = '';
    this._hostname = '';
    this._ipv4 = undefined;
    this._ipv6 = undefined;
    this._port = '';
    this._path = '';
    this._query = '';
    this._fragment = '';
    return this;
};

/******************************************************************************/

HTTPSBURI.prototype.schemeBit    = (1 << 0);
HTTPSBURI.prototype.userBit      = (1 << 1);
HTTPSBURI.prototype.passwordBit  = (1 << 2);
HTTPSBURI.prototype.hostnameBit  = (1 << 3);
HTTPSBURI.prototype.portBit      = (1 << 4);
HTTPSBURI.prototype.authorityBit = (HTTPSBURI.prototype.userBit | HTTPSBURI.prototype.passwordBit | HTTPSBURI.prototype.hostnameBit | HTTPSBURI.prototype.portBit);
HTTPSBURI.prototype.pathBit      = (1 << 5);
HTTPSBURI.prototype.queryBit     = (1 << 6);
HTTPSBURI.prototype.fragmentBit  = (1 << 7);
HTTPSBURI.prototype.allBit       = (0xFFFF);

/******************************************************************************/

//     URI = scheme ":" hier-part [ "?" query ] [ "#" fragment ]
//
//       foo://example.com:8042/over/there?name=ferret#nose
//       \_/   \______________/\_________/ \_________/ \__/
//        |           |            |            |        |
//     scheme     authority       path        query   fragment
//        |   _____________________|__
//       / \ /                        \
//       urn:example:animal:ferret:nose


HTTPSBURI.prototype.uri = function(uri) {
    if ( uri === undefined ) {
        return this.toString();
    }

    this.reset();

    var s = typeof uri === 'string' ? uri : '';

    // URI = scheme ":" hier-part [ "?" query ] [ "#" fragment ]
    //                                           ^^^^^^^^^^^^^^
    var pos = s.indexOf('#');
    if ( pos >= 0 ) {
        this._fragment = s.slice(pos + 1);
        s = s.slice(0, pos);
    }

    // URI = scheme ":" hier-part [ "?" query ]
    //                             ^^^^^^^^^^^

    pos = s.indexOf('?');
    if ( pos >= 0 ) {
        this._query = s.slice(pos + 1);
        s = s.slice(0, pos);
    }

    // URI = scheme ":" hier-part
    //       ^^^^^^

    pos = s.indexOf(':');
    if ( pos < 0 ) {
        throw new TypeError('HTTPSBURI.parse(): no scheme in "' + uri + '"');
    }
    this._scheme = s.slice(0, pos);
    s = s.slice(pos + 1);

    // URI =            hier-part
    //                  ^^^^^^^^^
    // hier-part = "//" authority path-abempty
    //           / path-absolute
    //           / path-rootless
    //           / path-empty

    pos = s.indexOf('//');

    // URN (no authority)
    if ( pos < 0 ) {
        this._path = s;
        return this;
    }

    // URL
    s = s.slice(pos + 2);
    pos = s.indexOf('/');
    if ( pos < 0 ) {
        // RFC3986 6.2.3.:
        // "In general, a URI that uses the generic syntax
        // for authority with an empty path should be
        // normalized to a path of '/' "
        this._path = '/';
    } else {
        this._path = s.slice(pos);
        s = s.slice(0, pos);
    }
    return this.authority(s);
};

/******************************************************************************/

// authority = [ userinfo "@" ] host [ ":" port ]
// port      = *DIGIT
// host      = IP-literal / IPv4address / reg-name

HTTPSBURI.prototype.authority = function(authority) {
    if ( authority === undefined ) {
        return this._hostname;
    }

    var s = authority;

    // HTTPSB ignores completely userinfo

    // authority = [ userinfo "@" ] host [ ":" port ]
    //              ^^^^^^^^^^^^^^

    var pos = s.indexOf('@');
    if ( pos >= 0 ) {
        s = s.slice(0, pos+ 1);
    }

    // authority =                  host [ ":" port ]
    //                                    ^^^^^^^^^^

    // Port for:
    //   IP-literal    = "[" ( IPv6address / IPvFuture  ) "]"
    pos = s.indexOf(']:');
    if ( pos >= 0 ) {
        if ( s.charAt(0) !== '[' ) {
            throw new TypeError('HTTPSBURI.parseAuthority(): invalid hostname: "' + authority + '"');
        }
        this._port = s.slice(pos + 2);
        s = s.slice(0, pos + 1);
    }

    // Port for other cases:
    //   IPv4address   = dec-octet "." dec-octet "." dec-octet "." dec-octet
    //   reg-name      = *( unreserved / pct-encoded / sub-delims )
    pos = s.indexOf(':');
    if ( pos >= 0 ) {
        this._port = s.slice(pos + 1);
        s = s.slice(0, pos);
    }

    // What is left is the hostname or ip (v4 or v6) address
    return this.hostname(s.toLowerCase());
};

/******************************************************************************/

HTTPSBURI.prototype.fragment = function(fragment) {
    if ( fragment === undefined ) {
        return this._fragment;
    }
    this._fragment = fragment;
    return this;
};

/******************************************************************************/

HTTPSBURI.prototype.hostname = function(hostname) {
    if ( hostname === undefined ) {
        return this._hostname;
    }
    this._hostname = hostname.toLowerCase();
    this._ipv4 = undefined;
    this._ipv6 = undefined;
    return this;
};

/******************************************************************************/

HTTPSBURI.prototype.domain = function(domain) {
    if ( domain !== undefined ) {
        return this.hostname(domain);
    }
    if ( !this._hostname ) {
        return '';
    }
    if ( this._ipv4 === undefined && this._ipv6 === undefined ) {
        this._ipv4 = HTTPSBURI.prototype.ipv4Regex.test(this._hostname);
        this._ipv6 = HTTPSBURI.prototype.ipv6Regex.test(this._hostname);
    }
    if ( this._ipv4 || this._ipv6 ) {
        return this._hostname;
    }
    // Definition od `domain`:
    // The hostname with the least number of labels for which cookies can
    // be set.
    // The shortest hostname matching the above definition is determined
    // from the "Public Suffix List" found at:
    // http://publicsuffix.org/list/

    
    return this;
};

/******************************************************************************/

HTTPSBURI.prototype.tld = function() {
};

/******************************************************************************/

//     URI = scheme ":" hier-part [ "?" query ] [ "#" fragment ]
//
//       foo://example.com:8042/over/there?name=ferret#nose
//       \_/   \______________/\_________/ \_________/ \__/
//        |           |            |            |        |
//     scheme     authority       path        query   fragment
//        |   _____________________|__
//       / \ /                        \
//       urn:example:animal:ferret:nose

HTTPSBURI.prototype.assemble = function(bits) {
    if ( bits === undefined ) {
        bits = this.allBits;
    }
    var s = '';
    if ( this._scheme && (bits & this.schemeBit) ) {
        s += this._scheme + ':';
    }
    if ( this._hostname && (bits & this.hostnameBit) ) {
        s += '//' + this._hostname;
    }
    if ( this._port && (bits & this.portBit) ) {
        s += ':' + this._port;
    }
    if ( this._path && (bits & this.pathBit) ) {
        s += this._path;
    }
    if ( this._query && (bits & this.queryBit) ) {
        s += '?' + this._query;
    }
    if ( this._fragment && (bits & this.fragmentBit) ) {
        s += '#' + this._fragment;
    }
    return s;
};

HTTPSBURI.prototype.toString = function() {
    return this.assemble();
};

/******************************************************************************/

HTTPSBURI.prototype.validateHostname = function(hostname) {
};

/******************************************************************************/



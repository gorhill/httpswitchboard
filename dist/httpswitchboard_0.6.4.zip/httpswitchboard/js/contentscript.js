// Injected into content pages
function preventJavascript(event) {
//    event.preventDefault();
    console.debug('preventJavascript() > %o', event);
}

(function() {
    var scripts = document.querySelectorAll('script');
    var i = scripts.length;
console.debug('Found %d scripts', i);
    var script;
    while ( i-- ) {
        script = scripts[i];
//        if ( script.src.trim() === '' ) {
            console.debug('script > %s', script.innerText);
            script.innerText = '';
//        }
    }
//    document.addEventListener("beforeload", preventJavascript, true);
})();


